package com.example.daryagoldscalper

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.Locale
import kotlin.math.max
import kotlin.math.min

data class Candle(val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)

data class Analysis(val signal: String, val buy: Int, val sell: Int, val rsi: Double,
                    val ema20: Double, val ema50: Double, val vwap: Double, val note: String)

object Engine {
    private fun ema(values: List<Double>, period: Int): Double {
        val k = 2.0 / (period + 1.0)
        return values.drop(1).fold(values.first()) { acc, v -> v * k + acc * (1 - k) }
    }
    fun analyze(c: List<Candle>): Analysis {
        if (c.size < 55) return Analysis("WAIT",0,0,50.0,0.0,0.0,0.0,
            "برای محاسبه پایدار، حداقل ۵۵ کندل بسته‌شده لازم است.")
        val closes = c.map { it.close }
        val e20 = ema(closes.takeLast(20),20)
        val e50 = ema(closes.takeLast(50),50)
        val changes = closes.zipWithNext { a,b -> b-a }.takeLast(14)
        val gains = changes.map { max(0.0,it) }.average()
        val losses = changes.map { max(0.0,-it) }.average()
        val rsi = if (losses == 0.0) 100.0 else 100.0 - 100.0/(1.0+gains/losses)
        val typicalVol = c.sumOf { ((it.high+it.low+it.close)/3.0)*it.volume }
        val totalVol = c.sumOf { it.volume }
        val vwap = if (totalVol > 0) typicalVol/totalVol else closes.last()
        val last = c.last()
        val prior = c.dropLast(1).takeLast(5)
        val brokeHigh = prior.isNotEmpty() && last.close > prior.maxOf { it.high }
        val brokeLow = prior.isNotEmpty() && last.close < prior.minOf { it.low }
        val buy = listOf(e20>e50, rsi>55, last.close>vwap, brokeHigh).count { it }
        val sell = listOf(e20<e50, rsi<45, last.close<vwap, brokeLow).count { it }
        val signal = when {
            buy >= 3 && last.close > e20 -> "BUY"
            sell >= 3 && last.close < e20 -> "SELL"
            else -> "WAIT"
        }
        return Analysis(signal,buy,sell,rsi,e20,e50,vwap,
            "سیگنال صرفاً بر اساس کندل‌های ورودی و پس از بسته‌شدن کندل محاسبه شده است.")
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Dashboard() } }
    }
}

@Composable
fun Dashboard() {
    var timeframe by remember { mutableStateOf("M5") }
    var capital by remember { mutableStateOf("1000000") }
    var minOrder by remember { mutableStateOf("6000000") }
    var entry by remember { mutableStateOf("3583.16") }
    var stop by remember { mutableStateOf("3580.00") }
    var target by remember { mutableStateOf("3589.48") }
    var riskPct by remember { mutableStateOf("0.25") }
    var demoBalance by remember { mutableStateOf(1_000_000.0) }
    val sample = remember {
        val base = 3590.0
        (0 until 60).map { i ->
            val close = base - i*0.11 + kotlin.random.Random(i).nextDouble(-0.18,0.18)
            Candle(close+0.08, close+0.22, close-0.25, close, 100.0+i)
        }
    }
    val analysis = remember(sample) { Engine.analyze(sample) }
    val cap = capital.toDoubleOrNull() ?: 0.0
    val risk = cap * ((riskPct.toDoubleOrNull() ?: 0.0)/100.0)
    val min = minOrder.toDoubleOrNull() ?: Double.MAX_VALUE
    val realEnabled = cap >= min

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Daryagold AI Scalper", style = MaterialTheme.typography.headlineMedium)
        Text("دستیار تحلیل اسکالپ انس طلا • نسخه آزمایشی", style = MaterialTheme.typography.bodyMedium)
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("وضعیت اتصال: متصل نیست", color = MaterialTheme.colorScheme.error)
                Text("حالت فعال: شبیه‌سازی داخلی — بدون ارسال سفارش واقعی")
                Text("بازار: XAUUSD")
            }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("تایم‌فریم تحلیل: ")
            FilterChip(selected=timeframe=="M5", onClick={timeframe="M5"}, label={Text("M5")})
            Spacer(Modifier.width(8.dp))
            FilterChip(selected=timeframe=="M15", onClick={timeframe="M15"}, label={Text("M15")})
        }
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("خروجی موتور نمونه", style=MaterialTheme.typography.titleLarge)
                Text("سیگنال: ${analysis.signal}", style=MaterialTheme.typography.headlineSmall,
                    color=when(analysis.signal) { "BUY" -> MaterialTheme.colorScheme.primary; "SELL" -> MaterialTheme.colorScheme.error; else -> MaterialTheme.colorScheme.secondary })
                Text("امتیاز خرید ${analysis.buy}/4  •  امتیاز فروش ${analysis.sell}/4")
                Text("RSI14: ${fmt(analysis.rsi)}")
                Text("EMA20: ${fmt(analysis.ema20)}")
                Text("EMA50: ${fmt(analysis.ema50)}")
                Text("VWAP: ${fmt(analysis.vwap)}")
                Text(analysis.note, style=MaterialTheme.typography.bodySmall)
                Text("توجه: داده فعلی نمونه داخلی است، نه قیمت زنده Daryagold.")
            }
        }
        Text("مدیریت سرمایه", style=MaterialTheme.typography.titleLarge)
        OutlinedTextField(capital,{capital=it},label={Text("سرمایه (تومان)")},singleLine=true)
        OutlinedTextField(minOrder,{minOrder=it},label={Text("حداقل مبلغ سفارش (تومان)")},singleLine=true)
        OutlinedTextField(riskPct,{riskPct=it},label={Text("ریسک هر معامله (%)")},singleLine=true)
        Text("ریسک مجاز هر معامله: ${risk.toLong()} تومان")
        Text("مانده شبیه‌سازی: ${demoBalance.toLong()} تومان")
        if (!realEnabled) Text("اجرای واقعی غیرفعال: سرمایه کمتر از حداقل سفارش اعلام‌شده است.",
            color=MaterialTheme.colorScheme.error)
        Text("ماشین‌حساب سناریوی معامله", style=MaterialTheme.typography.titleLarge)
        OutlinedTextField(entry,{entry=it},label={Text("قیمت ورود")},singleLine=true)
        OutlinedTextField(stop,{stop=it},label={Text("حد ضرر")},singleLine=true)
        OutlinedTextField(target,{target=it},label={Text("حد سود")},singleLine=true)
        val e=entry.toDoubleOrNull() ?: 0.0
        val s=stop.toDoubleOrNull() ?: 0.0
        val t=target.toDoubleOrNull() ?: 0.0
        val distance=kotlin.math.abs(e-s)
        val rr=if(distance>0) kotlin.math.abs(t-e)/distance else 0.0
        Text("نسبت سود به زیان: ${fmt(rr)}")
        Button(onClick={ if(distance>0) demoBalance -= risk }, enabled=distance>0) {
            Text("ثبت زیان فرضی در حساب آزمایشی")
        }
        OutlinedButton(onClick={demoBalance=1_000_000.0}) { Text("بازنشانی حساب آزمایشی") }
        Card {
            Column(Modifier.padding(16.dp)) {
                Text("اجرای واقعی")
                Text("قفل است — اتصال رسمی و شرایط قرارداد Daryagold هنوز تأیید نشده است.")
                Button(onClick={}, enabled=false) { Text("ارسال سفارش واقعی غیرفعال") }
            }
        }
        Text("این ابزار آموزشی/تصمیم‌یار است؛ سیگنال‌ها تضمین سود نیستند. قبل از استفاده واقعی، داده زنده، ارزش پوینت، کارمزد، اهرم و حجم قرارداد باید اعتبارسنجی شوند.",
            style=MaterialTheme.typography.bodySmall)
    }
}
fun fmt(v: Double) = String.format(Locale.US,"%.2f",v)
